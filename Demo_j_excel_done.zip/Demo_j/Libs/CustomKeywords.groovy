
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.Class

import com.kms.katalon.core.model.FailureHandling


 /**
	 * Example:
	 *
	 * You can run the following test case `Test Cases/test/CalculatorTestRunner` in Katalon Studio
	 * just as you run a usual test case by clicking the Run button.
	 *
	 * Test Case:
	 * <PRE>
	 * import junittutorial.CalculatorTest
	 * CustomKeywords.'com.kazurayam.ksbackyard.junit.JUnitCustomKeywordsTest.runWithJUnitRunner'(CalculatorTest.class)
	 * </PRE>
	 *
	 * The following is a JUnit test (localated at Include/scripts/groovy/junittutorial/CalculatorTest.groovy)
	 * executed by the above test case:
	 * <PRE>
	 * package junittutorial
	 *
	 * import static org.hamcrest.CoreMatchers.*
	 * import static org.junit.Assert.*
	 *
	 * import org.junit.Test
	 * import org.junit.runner.RunWith
	 * import org.junit.runners.JUnit4
	 *
	 * @RunWith(JUnit4.class)
	 * class CalculatorTest {
	 * 	@Test
	 * 	void testMultiply() {
	 * 		int expected = 21
	 * 		int actual = Calculator.multiply(7, 3)
	 * 		assertThat(actual, is(expected))
	 * 	}
	 *
	 * 	@Test
	 * 	void testDivide_wrongType() {
	 * 		double expected = 1.5f
	 * 		double actual = Calculator.divide(3, 2)
	 * 		assertThat(actual, is(not(expected)))
	 * 	}
	 *
	 * 	@Test
	 * 	void testDivide() {
	 * 		int expected = 1
	 * 		int actual = Calculator.divide(3, 2)
	 * 		assertThat(actual, is(expected))
	 * 	}
	 * }
	 * </PRE>
	 *
	 * Finally the class to be tested is located at `Keywords/junittutorial/Calculator.groovy`:
	 * <PRE>
	 * package junittutorial
	 *
	 * import com.kms.katalon.core.annotation.Keyword
	 *
	 * class Calculator {
	 *
	 * 	   @Keyword
	 * 	   static int add(int a, int b) {
	 * 		   return a + b;
	 * 	   }
	 *
	 * 	   @Keyword
	 * 	   static int subtract(int a, int b) {
	 * 		   return a - b;
	 * 	   }
	 *
	 * 	   @Keyword
	 * 	   static int multiply(int x, int y) {
	 * 		   return x * y
	 * 	   }
	 *
	 * 	   @Keyword
	 * 	   static int divide(int x, int y) {
	 * 		   return x / y
	 * 	   }
	 *
	 * 	   @Keyword
	 * 	   static int power(int a, int b){
	 * 		   int answer =a;
	 * 		   for (int x = 2; x <= b; x++){
	 * 		       answer *= a;
	 * 		   }
	 * 		   return answer;
	 *     }
	 * }
	 * </PRE>
	 *
	 * Please note that in the targeted Custom Keyword (e.g, Keywords/com/example/MiniScreenshotDriver.groovy) and
	 * JUnit test (e.g, Include/scripts/groovy/com/example/MiniScreenshotDriverTest.groovy), you can call
	 * any Katalon Studio API including org.openqa.selenium.WebDriver. Your JUnit invoked within Katalon Studio now
	 * can interact with your Application Under Test (web site) through WebDriver. This is what I wanted to achieve.
	 *
	 * @param junitRunnerClass
	 * @param flowControl
	 * @return
	 */ 
def static "com.kazurayam.junit4ks.JUnitCustomKeywords.runWithJUnitRunner"(
    	Class junitRunnerClass	
     , 	FailureHandling flowControl	) {
    (new com.kazurayam.junit4ks.JUnitCustomKeywords()).runWithJUnitRunner(
        	junitRunnerClass
         , 	flowControl)
}

 /**
	 * Run the given <code>junitRunnerClass</code> that is annotated with
	 * {@link JUnit} runner by invoke JUnit runner.
	 *
	 * @param junitRunnerClass a class that is annotated with {@link JUnit} runner.
	 *
	 * <p>
	 * Example of <code>junitRunnerClass</code>:
	 * <ul>
	 * <li>
	 * <pre>
	 * import org.junit.runner.RunWith
	 * import org.junit.runners.JUnit4
	 * &#64;RunWith(JUnit4.class)
	 * public class MyJunitRunner {}
	 *
	 * </pre>
	 * </li>
	 * </ul>
	 * </p>
	 * @return
	 */ 
def static "com.kazurayam.junit4ks.JUnitCustomKeywords.runWithJUnitRunner"(
    	Class junitRunnerClass	) {
    (new com.kazurayam.junit4ks.JUnitCustomKeywords()).runWithJUnitRunner(
        	junitRunnerClass)
}
